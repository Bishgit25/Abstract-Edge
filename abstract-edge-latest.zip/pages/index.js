import dynamic from "next/dynamic";
import { useEffect, useState } from "react";
import { ethers } from "ethers";

const TokenGrid = dynamic(() => import("../components/TokenGrid"));
const AiSuggestCard = dynamic(() => import("../components/AiSuggestCard"));
const TokenChart = dynamic(() => import("../components/TokenChart"));

const ERC20_ABI = ["function balanceOf(address) view returns (uint256)", "function decimals() view returns (uint8)"];

export default function Home() {
  const [topToken, setTopToken] = useState(null);
  const [walletAddress, setWalletAddress] = useState(null);
  const [ethBalance, setEthBalance] = useState(null);
  const [usdcBalance, setUsdcBalance] = useState(null);

  useEffect(() => {
    fetch("/api/tokens")
      .then(res => res.json())
      .then(data => setTopToken(data[0]))
      .catch(err => console.error("Token load error:", err));
  }, []);

  const connectWallet = async () => {
    if (typeof window.ethereum !== "undefined") {
      try {
        const provider = new ethers.providers.Web3Provider(window.ethereum);
        const accounts = await provider.send("eth_requestAccounts", []);
        const address = accounts[0];
        setWalletAddress(address);

        const ethBal = await provider.getBalance(address);
        setEthBalance(ethers.utils.formatEther(ethBal));

        const usdc = new ethers.Contract("0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48", ERC20_ABI, provider);
        const rawUsdc = await usdc.balanceOf(address);
        const decimals = await usdc.decimals();
        setUsdcBalance((rawUsdc / 10 ** decimals).toFixed(2));
      } catch (error) {
        console.error("Wallet connection failed:", error);
      }
    } else {
      alert("MetaMask not found. Please install it.");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-black to-gray-900 text-white p-4">
      <h1 className="text-3xl font-bold mb-6">Abstract Edge</h1>
      <button
        onClick={connectWallet}
        className="mb-4 px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl"
      >
        {walletAddress ? `Connected: ${walletAddress.slice(0, 6)}...${walletAddress.slice(-4)}` : "Connect Wallet"}
      </button>
      {walletAddress && (
        <div className="mb-4 text-sm text-white/80">
          <p>Ξ ETH: {ethBalance || "..."}</p>
          <p>USDC: {usdcBalance || "..."}</p>
        </div>
      )}
      <TokenGrid />
      <AiSuggestCard token={topToken} />
      <TokenChart token={topToken} />
    </div>
  );
}
